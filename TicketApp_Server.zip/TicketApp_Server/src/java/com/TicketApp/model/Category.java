/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.TicketApp.model;

/**
 *
 * @author Lenovo
 */
public enum Category {
    MOVIE,
    CONCERT,
    MATCH,
    WORKSHOP
}
